var structfdistrib =
[
    [ "dist", "structfdistrib.html#a76050892111c1abc1817a926980da3fe", null ],
    [ "offset", "structfdistrib.html#aed7ea92f45bd273dde380a45ddced592", null ],
    [ "size", "structfdistrib.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];