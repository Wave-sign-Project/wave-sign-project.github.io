var structdistrib =
[
    [ "offset", "structdistrib.html#aed7ea92f45bd273dde380a45ddced592", null ],
    [ "prec", "structdistrib.html#a5bfbd3b409ebe4bc09f9ed58d177c2bd", null ],
    [ "proba", "structdistrib.html#aa1732d6f59dd44c99dbd0702a6313cdc", null ],
    [ "size", "structdistrib.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];