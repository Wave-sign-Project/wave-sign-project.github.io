var dir_23ec12649285f9fabf3a6b7380226c28 =
[
    [ "bitstream.c", "bitstream_8c_source.html", null ],
    [ "bitstream.h", "bitstream_8h_source.html", null ],
    [ "compress.c", "compress_8c_source.html", null ],
    [ "compress.h", "compress_8h_source.html", null ],
    [ "compress_comb.c", "compress__comb_8c_source.html", null ],
    [ "djbsort.h", "djbsort_8h_source.html", null ],
    [ "djbsort_portable.c", "djbsort__portable_8c_source.html", null ],
    [ "gauss.c", "gauss_8c_source.html", null ],
    [ "gauss.h", "gauss_8h_source.html", null ],
    [ "hash.c", "hash_8c_source.html", null ],
    [ "hash.h", "hash_8h_source.html", null ],
    [ "mf3permut.c", "mf3permut_8c_source.html", null ],
    [ "mf3permut.h", "mf3permut_8h_source.html", null ],
    [ "popcount.h", "popcount_8h_source.html", null ],
    [ "test_gauss.c", "test__gauss_8c_source.html", null ],
    [ "tritstream.c", "tritstream_8c_source.html", null ],
    [ "tritstream.h", "tritstream_8h_source.html", null ]
];