var structvf3__e =
[
    [ "alloc", "structvf3__e.html#aef168a011892f8314c216e76850982a6", null ],
    [ "r0", "structvf3__e.html#a822aae7d4bca64c2a4f17b958e8e4a1a", null ],
    [ "r1", "structvf3__e.html#a8732d0418a089a91506a3b91e822a09a", null ],
    [ "size", "structvf3__e.html#a854352f53b148adc24983a58a1866d66", null ]
];