var structbitstream__t =
[
    [ "bit_pos", "structbitstream__t.html#aa1f0b94d4d341ab41864b4e482f1795b", null ],
    [ "buf_len", "structbitstream__t.html#ab3e45d7a98b5e813764d22620593d39d", null ],
    [ "byte_pos", "structbitstream__t.html#ad400656390a70837165f30b599b41e7f", null ],
    [ "data", "structbitstream__t.html#abe222f6d3581e7920dcad5306cc906a8", null ]
];