var searchData=
[
  ['len_128',['len',['../structperm__network__t.html#afed088663f8704004425cdae2120b9b3',1,'perm_network_t']]],
  ['length_5fremaining_129',['length_remaining',['../struct_a_e_s___x_o_f__struct.html#a471ecc33028fc91ee5fb93ab542b424b',1,'AES_XOF_struct']]]
];
