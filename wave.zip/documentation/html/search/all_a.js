var searchData=
[
  ['k_115',['K',['../params_8h.html#a97d832ae23af4f215e801e37e4f94254',1,'params.h']]],
  ['kat_5fcrypto_5ffailure_116',['KAT_CRYPTO_FAILURE',['../_n_i_s_t-kat_2_p_q_cgen_k_a_t__sign_8c.html#a290c938ee9fa6a46108815383ece99b8',1,'KAT_CRYPTO_FAILURE():&#160;PQCgenKAT_sign.c'],['../_p_q_cgen_k_a_t__sign_8c.html#a290c938ee9fa6a46108815383ece99b8',1,'KAT_CRYPTO_FAILURE():&#160;PQCgenKAT_sign.c']]],
  ['kat_5fdata_5ferror_117',['KAT_DATA_ERROR',['../_n_i_s_t-kat_2_p_q_cgen_k_a_t__sign_8c.html#ab208b46c8ba6c6e4e98112e95a76d70c',1,'KAT_DATA_ERROR():&#160;PQCgenKAT_sign.c'],['../_p_q_cgen_k_a_t__sign_8c.html#ab208b46c8ba6c6e4e98112e95a76d70c',1,'KAT_DATA_ERROR():&#160;PQCgenKAT_sign.c']]],
  ['kat_5ffile_5fopen_5ferror_118',['KAT_FILE_OPEN_ERROR',['../_n_i_s_t-kat_2_p_q_cgen_k_a_t__sign_8c.html#a8660753225cbee577a1d12c337f09b81',1,'KAT_FILE_OPEN_ERROR():&#160;PQCgenKAT_sign.c'],['../_p_q_cgen_k_a_t__sign_8c.html#a8660753225cbee577a1d12c337f09b81',1,'KAT_FILE_OPEN_ERROR():&#160;PQCgenKAT_sign.c']]],
  ['kat_5fsuccess_119',['KAT_SUCCESS',['../_n_i_s_t-kat_2_p_q_cgen_k_a_t__sign_8c.html#a4686e444b128bdb008f888f00759a76b',1,'KAT_SUCCESS():&#160;PQCgenKAT_sign.c'],['../_p_q_cgen_k_a_t__sign_8c.html#a4686e444b128bdb008f888f00759a76b',1,'KAT_SUCCESS():&#160;PQCgenKAT_sign.c']]],
  ['key_120',['key',['../struct_a_e_s___x_o_f__struct.html#ad4cac93cc3b317b801edca4af3b610d3',1,'AES_XOF_struct']]],
  ['key_121',['Key',['../struct_a_e_s256___c_t_r___d_r_b_g__struct.html#a834c237b7ea5b3b5a2b399dd1efc4416',1,'AES256_CTR_DRBG_struct']]],
  ['keygen_122',['keygen',['../keygen_8h.html#a0e4895ef57a1974988af0e86c66c79c9',1,'keygen(wave_sk_t *sk, wave_pk_t *pk):&#160;keygen.c'],['../keygen_8c.html#a0e4895ef57a1974988af0e86c66c79c9',1,'keygen(wave_sk_t *sk, wave_pk_t *pk):&#160;keygen.c']]],
  ['keygen_2ec_123',['keygen.c',['../keygen_8c.html',1,'']]],
  ['keygen_2eh_124',['keygen.h',['../keygen_8h.html',1,'']]],
  ['keygen_5ftest_2ec_125',['keygen_test.c',['../keygen__test_8c.html',1,'']]],
  ['ku_126',['KU',['../params_8h.html#a390b3c8042773d7fd018c8ad7f2b4988',1,'params.h']]],
  ['kv_127',['KV',['../params_8h.html#a06ba0516460330333f48ef077a976865',1,'params.h']]]
];
