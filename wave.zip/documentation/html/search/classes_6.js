var searchData=
[
  ['perm_5fnetwork_5ft_366',['perm_network_t',['../structperm__network__t.html',1,'']]]
];
