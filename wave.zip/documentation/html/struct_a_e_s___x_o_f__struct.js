var struct_a_e_s___x_o_f__struct =
[
    [ "buffer", "struct_a_e_s___x_o_f__struct.html#a2aa039eae5ea240f3cf5fd1a85f10efd", null ],
    [ "buffer_pos", "struct_a_e_s___x_o_f__struct.html#a8a37d41b7b076eced766d7418450477d", null ],
    [ "ctr", "struct_a_e_s___x_o_f__struct.html#a3b4503a7a07e395db41b6b09c901fe21", null ],
    [ "key", "struct_a_e_s___x_o_f__struct.html#ad4cac93cc3b317b801edca4af3b610d3", null ],
    [ "length_remaining", "struct_a_e_s___x_o_f__struct.html#a471ecc33028fc91ee5fb93ab542b424b", null ]
];