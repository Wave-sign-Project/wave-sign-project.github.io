var structreject__t =
[
    [ "offset", "structreject__t.html#aed7ea92f45bd273dde380a45ddced592", null ],
    [ "range", "structreject__t.html#a2884416957d0808e80a6a85c1aaac074", null ],
    [ "size", "structreject__t.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];