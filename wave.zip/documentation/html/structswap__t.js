var structswap__t =
[
    [ "max", "structswap__t.html#ac66b569507cc273bbf83ce5dd5f70e84", null ],
    [ "min", "structswap__t.html#a1a1f4624f66ab0b2eb0b98316514c369", null ]
];