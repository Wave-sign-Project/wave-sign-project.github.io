var structperm__network__t =
[
    [ "len", "structperm__network__t.html#afed088663f8704004425cdae2120b9b3", null ],
    [ "swap", "structperm__network__t.html#a536a0e318ee786c842b767fd023dd837", null ]
];