var structwave__sk__t =
[
    [ "b", "structwave__sk__t.html#a3840f24b658ffdfe4186118a333075f5", null ],
    [ "c", "structwave__sk__t.html#a9304c2b781aedf470d2322cc61792ef0", null ],
    [ "mk", "structwave__sk__t.html#a24074ff15ae9c333b3c71f25bda0b5c7", null ],
    [ "perm", "structwave__sk__t.html#ade4db3b1cec93a6d13d108f82744143d", null ]
];