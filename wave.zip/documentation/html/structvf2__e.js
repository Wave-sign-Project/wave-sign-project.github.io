var structvf2__e =
[
    [ "alloc", "structvf2__e.html#aef168a011892f8314c216e76850982a6", null ],
    [ "size", "structvf2__e.html#a854352f53b148adc24983a58a1866d66", null ],
    [ "x", "structvf2__e.html#ae15a880f1fda135114ca30c5aaeb8738", null ]
];